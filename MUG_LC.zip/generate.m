function game = generate(game)
% GENERATE generate actions of player and states of coplayer
%
% game = structure describing the game, see game_con
%
% designed: MK
% updated : 18.4.17, JH 17.5.17, JH 13.2.18, JH 10.4.18

%% Current recorded state - last state and last action 
   % player A
    Ast = game.data(4,game.t-1); % last environment state for the player A = last action of the player B
    Aat = game.data(1,game.t-1); % last action of the player A  
   %player B
    Bst = game.data(1,game.t-1); % last environment state for the player B = last action of the player A
    Bat = game.data(4,game.t-1); % last action of the player B
    
%% New actions 
   %player A     
   pr  = game.playerA.Sarray(:,Aat,Ast);    % choosing the optimal strategy
   Aat1  = dnoise(pr);
   game.data(1,game.t)= Aat1;   % new action of the player A
   Bst1=Aat1;                   % new environment state for the player B = new action of the player A
   % Player B     
   pr  = game.playerB.Sarray(:,Bat,Bst);    % choosing the optimal strategy
   Bat1  = dnoise(pr);          
   game.data(4,game.t)= Bat1;   % new action of the player B
   Ast1=Bat1;                   % new environment state for the player A = new action of the player B

%% New reward  
   game.data(2,game.t)=game.playerA.Rarray(Ast,Ast1,Aat1);  % reward (playerB now, playerB last, playerA action)
   game.data(5,game.t)=game.playerB.Rarray(Bst,Bst1,Bat1);  % reward (playerA now, playerA last, playerB action)
 
%% Initialization of the cumulative profit
  if game.t==2
       % first result of the game
       if Aat+Bat<=game.q 
        chi =1;     % result-type indicator [1 = unused potential, 0 = overshoot]
       else
        chi = 0;
       end  
       % first profit - player A
       game.data(2,game.t-1)=chi*Aat; % reward of the playerA
       game.data(3,game.t-1)=chi*Aat; % cumulative profit of the playerA
       % first profit - player B 
       game.data(5,game.t-1)=chi*Bat; % reward of the playerB
       game.data(6,game.t-1)=chi*Bat; % cumulative profit of the playerB
  end
 
%% Game round result after applying the new actions
% Result-type indicator for the round in the time t
   if Aat1+Bat1<=game.q 
       chi =1;      % unused potential
   else
       chi = 0;     % overshoot
   end 
   
% Results saving
      game.data(3,game.t)=game.data(3,game.t-1)+chi*Aat1;   % cumulative profit of the playerA
      game.data(6,game.t)=game.data(6,game.t-1)+chi*Bat1;   % cumulative profit of the playerB 
      game.final=game.data([3,6],game.t);                   % final total profits of both players in the given time t
      game.data(7,game.t)=game.data(7,game.t-1)+chi;        % number of realized demands
end 
    