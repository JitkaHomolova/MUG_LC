function player = player_con(ns,na,w,v,N,type,person,model)
% PLAYER_CON constructs the player potentially exploiting MDP
%
%  player = player_con(ns,na,w,v,N,type,person)
%  player = player_con(ns,na,w,v,N,type) 1 
%  player = player_con(ns,na,w,v,N) [0,0]
% 
%  player = structure describing the player containing
%
%  ns     = the number of states  s_{t}
%  na     = the number of actions a_{t} 
%   w     = the parameter for creating the reward
%   v     = the parameter for creating the environment model
%   N     = the number of game rounds
%   type  = type of the acting [optimizing,learning]in[{0,0},{0,1},{1,0},{1,1}]
%  person = structure describing personal characteristics of the player in[{A,B}]

% Created here 
%  Rarray = reward R(s_{t+1},s_{t},a_{t}|w)
%  Parray = environment model p(s_{t+1}|a_{t},s_{t},v)
%  Sarray = strategy p(a_{t}|s_{t})
%  Barray = Bellman_function(s_{t},1:N)  

% designed: MK
% updated : 18.4.17, JH 7.6.17, JH 2.11.17, JH 10.4.18

if isempty(person), model = 1;end             % type of model of B not defined
if isempty(person), person ='A';end           % no personal characteristics
if isempty(type), type =[1,1];end             % type of the player [optimizing, learning] 

% Constructions
Rarray    = reward_con(ns,na,w);              % constructing of the reward
Parray    = model_con(ns,na,v,type,model);    % constructing of the environment model
Sarray    = Parray;                           % constructing of the strategy model coinciding with environment with st and at1 swapped
Barray    = zeros(ns,na);                     % the array for storing Bellman function V(s_{t},a_{t})

player    = struct('ns',ns,'na',na,'w',w,'v',v,'N',N,'type',type,'person',person, 'model', model, 'Rarray',Rarray,'Parray',Parray,'Sarray',Sarray,'Barray',Barray);
end