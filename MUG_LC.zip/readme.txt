Dear user,

the m-files in this directory belong to the RR package 
for the ECML PKDD 2018 (paper ID 381). 
These procedures, functions, etc. serve to demonstrate 
the experiment "Modified Ultimatum Game with Learning". 
Parameters of the experiment are preset as defaults 
or can be modified by dialogues.

The program was developed in Matlab environment. 
The package consists of the following 13 files: 

  readme.txt         this file

  mainCL.m           the main file: runs the experiment; 
		     
    introduction.m   auxiliary file: setting of the game parameters
    player_con.m     auxiliary file: player design
    reward_con.m     auxiliary file: reward design
    model_con.m      auxiliary file: model design
    game_con.m       auxiliary file: game design
    design.m         auxiliary file: strategy design
    generate.m       auxiliary file: action and state design
    learn.m          auxiliary file: learning process design
    dynprog.m        auxiliary file: optimal strategy design
    dnoise.m         auxiliary file: discrete noise simulator
    graph_mesh.m     auxiliary file: graphical representation of the results			 		