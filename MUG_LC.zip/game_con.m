function game = game_con(playerA,playerB,se)
% GAME_CON constructs the structure game for given amount splitting.
%
%   game = game_con(playerA,playerB,see) 1
%
%     game    = the structure completely describing the game 
%     playerA = the structure describing player A filled by player_con  
%     playerB = the structure describing player B filled by player_con
%     se      = intial value of seed

%  CONTENT CREATED HERE 
%     t             - time corresponding to the current round
%     data          - (7,N) array: the first  row contains actions of A 
%                                  the second row contains reward of A 
%                                  the third  row contains cummulative gain (profit) of A
%                                  the fourth row contains actions of B
%                                  the fifth  row contains reward of B
%                                  the sixth  row contains cummulative gain (profit) of B 
%                                  the seventh row contains number of realized demands
%                                  the number of game rounds N is a part of player

% designed: MK
% updated : 18.4.17, JH 12.5.17, JH 10.4.18

%% Initialization
N    = playerA.N;                  % the number of rounds 
q    = playerA.ns+1;               % the amount to be split
pud=0;  final=[0,0];               % percentage of unrealized demands
data = zeros(7,N);                 % recorded game course 
data(1,1) = 3;                     % fixed initial state
data(4,1) = 3;
t    = 1;                          % it corresponds with initial state

%% Constructions
% Player A
if playerA.type(1)== 0             
   playerA.Sarray = playerA.Parray; % no optimization
else
   playerA = dynprog(playerA,t);    % optimization: setting of the optimal strategy for selected model   
end

% Player B
if playerB.type(1)== 0             
   playerB.Sarray = playerB.Parray; % no optimization
else
   playerB = dynprog(playerB,t);    % optimization: setting of the optimal strategy for selected model  
end
   game = struct('N', N, 'q', q,'playerA',playerA,'playerB',playerB,'t',t,'data',data,'se',se,'pud',pud,'final',final);  
end
