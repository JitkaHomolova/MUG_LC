function Rarray = reward_con(ns,na,w)
% REWARD_CON constructs the reward of the player prepared for given amount q splitting
%
%  Rarray = reward_con(ns,na,w)
%  
%  Rarray = reward R(s_{t},s_{t+1},a_{t}|w)     
%  ns     = the number of states  s_{t}
%  na     = the number of actions a_{t} 
%   w     = the parameter w in [0,1] for creating the reward

%  The amount to be split is equal q=ns+1 because state s_{t} is in {1,2,...,q-1}.

% designed: MK
% updated : 18.4.17., JH 18.5.,  JH 2.11.17, JH 10.4.18

Rarray = zeros(ns,ns,na);
for st = 1:ns
    for st1 = 1:ns
        for at = 1:na
            % total amount exceeded (overshoot)
            if st+at>ns+1, 
                Rarray(st,st1,at)= -w*abs(ns+1-st-at);     % the made choice intentionally does not depend on delayed state
            % an amount left (unused potential)    
            else
                Rarray(st,st1,at)= at-w*abs(ns+1-st-at);
            end
        end
    end
end    
    

    
    

  
  