function graph = graph_mesh(omStep,resultsA,resultsB,resultsTOTAL,resultsPud)
% GRAPH_MESH draws mesh graphs of the game results in dependence on the
% omegas combination
%
%   omStep       = the step of increasing the parameter omega
%   resultsA     = the profit of the player A    
%   resultsB     = the profit of the player B  
%   resultsTOTAL = the profit of both players  
%   resultsPud   = the success rate of the game
%
% designed: JH
% updated : 15.3.18, JH 10.4.18

%% Initialization
fig=1;
[X,Y] = meshgrid(0:omStep:1);   % axis grid for the omegas

%% Graphs construction
% Profit of the player A
figure(fig)
p1 = mesh(X,Y,resultsA); 
xlabel('Omega A','FontSize',12)
ylabel('Omega B','FontSize',12)
zlabel('Profit','FontSize',12)
title(['Total cumulative profit of agent A'],'FontSize',14)
saveas(gcf,'ProfitA','pdf')

fig=fig+1;

% Profit of the player B
figure(fig)
p2 = mesh(X,Y,resultsB); 
xlabel('Omega A','FontSize',12)
ylabel('Omega B','FontSize',12)
zlabel('Profit','FontSize',12)
title(['Total cumulative profit of agent B'],'FontSize',14)
saveas(gcf,'ProfitB','pdf')

fig=fig+1;

% Profit of the whole game
figure(fig)
p3 = mesh(X,Y,resultsTOTAL); 
xlabel('Omega A','FontSize',12)
ylabel('Omega B','FontSize',12)
zlabel('Profit','FontSize',12)
title(['Total cumulative profit of both agents'],'FontSize',14)
saveas(gcf,'TotalProfit','pdf')

fig=fig+1;

% Success rate of the game
figure(fig)
p4 = mesh(X,Y,resultsPud); 
xlabel('Omega A','FontSize',12)
ylabel('Omega B','FontSize',12)
zlabel('Success Rate','FontSize',12)
title(['Success rate of games'],'FontSize',14)
saveas(gcf,'SuccessRate','pdf')
