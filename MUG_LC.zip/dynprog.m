function player = dynprog(player,t)
% DESIGN designs strategy of player by dynamic programming
%
% player = structure describing the player, see player_con
% t      = current time 
%
% designed: MK
% updated : 20.4.17, JH 12.5.17, JH 10.4.18

%% Initialization
N = player.N;                                    % end of the game
player.Barray(:,:)= 0*player.Barray(:,:);        % terminal condition
Barray(:,:) = player.Barray(:,:);                % working Bellman function

%% Construction
for tau = N:-1:t                                 % cycle up to horizon
  for st1 = 1:player.ns                          % cycle over old state
    for at1 = 1:player.na                        % cycle over old actions
        H   = zeros(1,player.na);
        player.Sarray(:,st1,at1) = 0*player.Sarray(:,st1,at1); 
        for at = 1:player.na 
            pr = player.Parray(:,st1,at);        % normalizing of probabilities          
            pr = pr/sum(pr);
          H(at)= (player.Rarray(:,st1,at)' + Barray(:,at)')*pr;      
        end
        [am,ia] = max(H);                        % maximum value
        player.Sarray(ia,st1,at1)=1;             % only the last value is kept
        Barray(st1,at1) = am;
    end
  end
  player.Barray = Barray;                        % Bellman function at given tau 
end  
   
    
  
    