function Parray = model_con(ns,na,v,type,model)
% MODEL_CON constructs environment model used by the player (prepared for
% cake splitting)
%
%  Parray = model_con(ns,na,v,type,model)
%  
%  Parray = probability(s_{t+1}|s_{t},a_{t},v)
%  ns     = the number of states  s_{t}
%  na     = the number of actions a_{t} 
%   v     = the parameter v in [0,1] for flattening this transition probability
%  type   = the on/off parameter of optimization and learning; 
%         = [optimization, learning]
%  model  = type of model of player in [1,2] (sets the prior knowldge in case of learning)
%         = [even distribution, prior knowledge]
%
% Comment: It is sampled exponential pd with expectation selected so that a
%          change of s_{t} decrease the difference q - s_{t-1}-a_{t-1}
%          proportionate to the previous actions and there is no change in
%          case of "small" demand.

% designed: MK
% updated : 18.4.17, JH 12.5.17, , JH 7.6.17, JH 2.11.17, JH 12.2.18, JH
%           10.4.18

Parray = ones(ns,ns,na)/ns;     % initialization
sigma=6;                        % standard deviation of the Gauss distribution
if v>0
    % Learning case
    if type(2)==1
         for st1 = 1:ns
            for at1 = 1:na
                
                % No prior knowledge
                if model==1     % even distribution
                    Parray(:,st1,at1)= Parray(:,st1,at1)/sum(Parray(:,st1,at1));
                
                % Prior knowledge
                elseif model==2 % realistic 
                     if at1 <= 5
                        if ns+1-at1-st1 <= 0 % total amount exceeded (overshooot)
                            Parray(:,st1,at1)= exp((-([1:ns]'-st1).^2)/(2*sigma^2)); 
                        else                 % an amount left (unused potential)
                            Parray(:,st1,at1)= exp((-([1:ns]'-st1*(1+(ns+1-at1-st1)/(st1+at1))).^2)/(2*sigma^2));
                        end
                     else  % at1 > 5
                        if ns+1-at1-st1 <= 0 % total amount exceeded (overshoot)
                            Parray(:,st1,at1)= exp((-([1:ns]'-st1*(1+(ns+1-at1-st1)/(st1+at1))).^2)/(2*sigma^2)); 
                        else                 %an amount left (unused potential)
                            Parray(:,st1,at1)= exp((-([1:ns]'-st1*(1+(ns+1-at1-st1)/(st1+at1))).^2)/(2*sigma^2));
                        end
                     end 
                end
            end
        end
    end
    % No learning case
    if type(2)==0
        for st1 = 1:ns
            for at1 = 1:na
                if at1 <= 5
                        if ns+1-at1-st1 <= 0 % total amount exceeded (overshoot)
                            Parray(:,st1,at1)= exp((-([1:ns]'-st1).^2)/(2*sigma^2)); 
                        else                 % an amount left (unused potential)
                            Parray(:,st1,at1)= exp((-([1:ns]'-st1*(1+(ns+1-at1-st1)/(st1+at1))).^2)/(2*sigma^2));
                        end
                else  %at1 > 5
                        if ns+1-at1-st1 <= 0 % total amount exceeded (overshoot)
                            Parray(:,st1,at1)= exp((-([1:ns]'-st1*(1+(ns+1-at1-st1)/(st1+at1))).^2)/(2*sigma^2)); 
                        else                 % an amount left (unused potential)
                            Parray(:,st1,at1)= exp((-([1:ns]'-st1*(1+(ns+1-at1-st1)/(st1+at1))).^2)/(2*sigma^2));
                        end
                end
            end
            Parray(:,st1,at1)= Parray(:,st1,at1)/sum(Parray(:,st1,at1));
            end
        end
    end
end    
    

    
    

  
  