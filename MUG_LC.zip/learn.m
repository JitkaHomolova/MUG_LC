function game = learn(game)
% LEARN learns the model of environment (co-player)
%
% game = structure describing the game, see game_con
%
% designed: MK 
% updated : 18.4.17, JH 22.6.17, JH 10.4.18

%% Updating
% Player A
if game.playerA.type(2)==1
   st  = game.data(4,game.t);       % new state of the environment for the player A = new action of the player B
   st1 = game.data(4,game.t-1);     % previous state of the environment for the player A = previous action of the player B
   at1 = game.data(1,game.t-1);     % previous action of the player A
   game.playerA.Parray(st,st1,at1) = game.playerA.Parray(st,st1,at1) + 1; % occurance update
end  
% Player B
if game.playerB.type(2)==1
   st  = game.data(1,game.t);       % new state of the environment for the player B = new action of the player A
   st1 = game.data(1,game.t-1);     % previous state of the environment for the player B = previous action of the player A
   at1 = game.data(4,game.t-1);     % previous action of the player B
   game.playerB.Parray(st,st1,at1) = game.playerB.Parray(st,st1,at1) + 1; % occurance update
end
    
    