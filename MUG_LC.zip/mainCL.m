function game = mainCL()
%% Main program for modified UG with learning
%
% designed: MK
% updated : 18.4.17, JH 12.5.17, EZ 31.10., JH 2.11.17, JH 18.1.18, JH
% 13.2.18, EZ 6.4.18, JH 9.4.18

%% Preliminary
close all
clear all

clc
%% Initiation 
disp('.............WELCOME TO MODIFIED ULTIMATUM GAME WITH LERNING!..............')
disp('...........................................................................')
disp('.............NOW YOU CAN SET THE PARAMETERS OF THE EXPERIMENT..............')
disp('INSTRUCTIONS: PRESS ENTER FOR DEFAULTS OR IF YOU DO NOT KNOW WHAT THEY MEAN')
disp('.......Computation time with default configuration is about 3 minutes......')
disp('===========================================================================')
ST = 1;
s=input(['Do you want to store experimental data? {0 = No, 1 = Yes} ST = ',num2str(ST),'  '],'s');
if ~isempty(s)
    while s ~= '0' && s ~= '1'
        s=input(['Ivalid input. Please select values 0/1 or press Enter to keep the default option. '],'s');
        if isempty(s), s = num2str(ST); break; end
    end
    ST = str2double(s);
end

numGames = 20;
s = input(['Choose the number of games: N = ', num2str(numGames),' '],'s');
if ~isempty(s) 
    while floor(str2double(s)) ~= str2double(s) || str2double(s) <= 0
        s =input(['Ivalid input. Please select a positive integer or press Enter to keep the default option. '],'s');
        if isempty(s), s = num2str(numGames); break; end
    end
    numGames = str2double(s);
end

seed = 49;
s = input(['Choose the seed for reproducibility: seed = ', num2str(seed),' '],'s');
if ~isempty(s) 
    while isnan(str2double(s))
        s =input(['Ivalid input. Please select a number or press Enter to keep the default option. '],'s');
        if isempty(s), s = num2str(seed); break; end
    end
    seed = str2double(s);
end

omStep = 1/3;
s = input(['Choose the step of increasing the parameter omega: omegaStep = ', num2str(omStep),' '],'s');
if ~isempty(s) 
    while isnan(str2double(s)) || str2double(s) <= 0 || str2double(s) >= 1
        s =input(['Ivalid input. Please select a number from the interval (0,1) or press Enter to keep the default option. '],'s');
        if isempty(s), s = num2str(omStep); break; end
    end
    omStep= str2double(s);
end

fig = 1;                                          % figure and game counter
game = [];                                        % game structure                            
%% Cycle over games
% Initialization of results 
numOm = 1/omStep+1;                 % number of omegas combinations in the experiment
resultsA = zeros(numOm, numOm);     % resulting profits of the player A for the given omegas combination
resultsB = zeros(numOm, numOm);     % resulting profits of the player B for the given omegas combination
resultsPud = zeros(numOm, numOm);   % resulting success rate for the given omegas combination
    
% Cycle over the omega parameters 
indexomegaA=0;                      % omegaA counter initialization
for omegaA = 0:omStep:1             % cycle over omegaA (player A)
    indexomegaA=indexomegaA+1;      % omegaA counter update
    indexomegaB=0;                  % omegaB counter initialization
    for omegaB = 0:omStep:1         %% cycle over omegaB (player B)
        indexomegaB=indexomegaB+1;  % omegaB counter update
        
        % Introductory dialogue for game tuning 
        game = introduction(game,omegaA,omegaB,seed,numGames);  % construction of game via initial dialogue 
        while(game.t<game.N)                                    % cycle over the game rounds
                game.t = game.t +1;                             % round counter
                game = design(game);                            % strategy design
                game = generate(game);                          % generation of the actions and states
                game = learn(game);                             % model learning
        end
                    
        game.pud=game.data(7,game.N)/game.N;    % success rate
        
        con = 1;                                % continuation indicator
        if con<=0,  fig = con*fig; else fig = fig + 1; end
        rev = 0; 
        if rev, 
            game=game, 
            keyboard, 
        end
        
%% Storing chain of experimental results
% Data update
 resultsA(indexomegaA,indexomegaB) = game.final(1);     % profit of the player A
 resultsB(indexomegaA,indexomegaB) = game.final(2);     % profit of the player B
 resultsPud(indexomegaA,indexomegaB) = game.pud;        % success rate of the game
 resultsTOTAL = resultsA + resultsB;                    % profit of the both players
end
end

% Graphic view
graph_mesh(omStep,resultsA,resultsB,resultsTOTAL,resultsPud) % mesh graphs construction

% Data saving
if ST
    save('results_A','resultsA')
    save('results_B','resultsB')
    save('results_Pud','resultsPud')
    save('results_Total','resultsTOTAL')
end