function game = introduction(game,omegaA,omegaB,seed,Nu)
% INTRODUCTION sets parameters of the game

% designed: MK
% updated : 18.4.17, JH 12.5.17, JH 2.11.17, JH 13.3., EZ 6.4.18, JH 9.4.18

% game = structure describing the game: see game_con
% con  = continuation indicator {0/1} new serie / continuation
% clc                   % clear screen
%% Defaults
if isempty(game)
N     = Nu;           % the number of rounds
q     = 10;           % the amount to be split 
se    = seed;         % the seed for reproducibility

% Initialization of the players (default setting)
% Player A
typeA = [1,1];        % player A: optimizing and learning player
wA    =  omegaA;      % the weight in [0,1] controlling cooperativeness              
vA    =  0.95;        % the weight controlling environment model used by player A
modelA = 1;           % the type of prior knowledge model used by player A in {1=even distribution,2=realistic} 

% Player B
typeB = [1,1];        % optimizing and learning player
wB    =  omegaB;      % the weight in [0,1] controlling cooperativeness    
vB   =   0.95;        % the weight controlling environment model used by B
modelB = 1;           % the type of prior knowledge model used by player B in {1=even distribution,2=realistic}  

%% Dialogues
% Player A
disp('TALK ABOUT PLAYER A')
s=input(['Does the player A optimize? {0 = No, 1 = Yes} typeA(1) = ',num2str(typeA(1)),'  '],'s');
if ~isempty(s)
    while s ~= '0' && s ~= '1'
        s=input(['Invalid input. Please select values 0/1 or press Enter to keep the default option. '],'s');
        if isempty(s), s = num2str(typeA(1)); break; end
    end
    typeA(1) = str2double(s);
end

if typeA(1) == 1
    s=input(['Does the player A learn? {0 = No, 1 = Yes} typeA(2) = ',num2str(typeA(2)),'  '],'s');
    if ~isempty(s)
        while s ~= '0' && s ~= '1'
            s=input(['Invalid input. Please select values 0/1 or press Enter to keep the default option. '],'s');
            if isempty(s), s = num2str(typeA(2)); break; end
        end
        typeA(2) = str2double(s);
    end
end

if typeA(2) == 1
   s=input(['Does the player A have a prior knowledge? {1 = No, 2 = Yes} modelA = ',num2str(modelA),'  '],'s');
   if ~isempty(s)
    while s ~= '2' && s ~= '1'
        s=input(['Invalid input. Please select values 1/2 or press Enter to keep the default option. '],'s');
        if isempty(s), s = num2str(modelA); break; end
    end
    modelA = str2double(s);
   end
end

% Player B
disp('TALK ABOUT PLAYER B')

s=input(['Does the player B optimize? {0 = No, 1 = Yes} typeB(1) = ',num2str(typeB(1)),'  '],'s');
if ~isempty(s)
    while s ~= '0' && s ~= '1'
        s=input(['Invalid input. Please select values 0/1 or press Enter to keep the default option. '],'s');
        if isempty(s), s = num2str(typeB(1)); break; end
    end
    typeB(1) = str2double(s);
end

if typeB(1) == 1
    s=input(['Does the player B learn? {0 = No, 1 = Yes} typeB(2) = ',num2str(typeB(2)),'  '],'s');
    if ~isempty(s)
        while s ~= '0' && s ~= '1'
            s=input(['Invalid input. Please select values 0/1 or press Enter to keep the default option. '],'s');
            if isempty(s), s = num2str(typeB(2)); break; end
        end
        typeB(2) = str2double(s);
    end
end


if typeB(1) == 0
   s=input(['Does the player B have a prior knowledge? {1 = No, 2 = Yes} modelB = ',num2str(modelB),'  '],'s');
   if ~isempty(s)
    while s ~= '2' && s ~= '1'
        s=input(['Invalid input. Please select values 1/2 or press Enter to keep the default option. '],'s');
        if isempty(s), s = num2str(modelB); break; end
    end
    modelB = str2double(s);
   end
end
disp('WAIT A MOMENT, I NEED TO COMPUTE ...')

%% Recovering values from previous game    
else                  
   N  = Nu;      
   q  = game.q;
   se = seed;
   typeA = game.playerA.type;
   typeB = game.playerB.type;
   wA    = omegaA;
   wB    = omegaB;
   vA    = game.playerA.v;
   vB    = game.playerB.v;
   modelA = game.playerA.model;
   modelB = game.playerB.model;
end

rand('twister',se);
%% Constructions
ns = q-1;   % number of possible states
na = q-1;   % number of possible actions

% player A construction
playerA = player_con(ns,na,wA,vA,N,typeA,'A',modelA);  

% player B construction
playerB = player_con(ns,na,wB,vB,N,typeB,'B',modelB);  

% game construction
game = game_con(playerA,playerB,se);
end

