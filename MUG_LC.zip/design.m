function game = design(game)
% DESIGN designs strategies of players
%
% game = structure describing the game, see game_con
%
% designed: MK
% updated : 18.4.17, JH 10.4.18

%% Constructions
% Player A
if game.playerA.type(1)== 1
   game.playerA  = dynprog(game.playerA,game.t);          % optimization: dynamic programming
else    
   game.playerA.Sarray = game.playerA.Parray;             % no optimization: use the default strategy  
end

% Player B
if game.playerB.type(1)== 1
   game.playerB  = dynprog(game.playerB,game.t);          % optimization: dynamic programming
else
   game.playerB.Sarray = game.playerB.Parray;             % no optimization: use the default strategy 
end  
       